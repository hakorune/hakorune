//! Phase 29ca P1: Generic structured loop v0 facts (ExitIf-capable, no carriers)

use crate::ast::{ASTNode, BinaryOperator};
use crate::mir::builder::control_flow::plan::extractors::common_helpers::{
    extract_loop_increment_plan,
};
use crate::mir::builder::control_flow::plan::coreloop_body_contract::is_effect_only_stmt;
use crate::mir::builder::control_flow::plan::planner::Freeze;

#[derive(Debug, Clone)]
pub(in crate::mir::builder) struct GenericLoopV0Facts {
    pub loop_var: String,
    pub condition: ASTNode,
    pub loop_increment: ASTNode,
    pub body: Vec<ASTNode>,
}

pub(in crate::mir::builder) fn try_extract_generic_loop_v0_facts(
    condition: &ASTNode,
    body: &[ASTNode],
) -> Result<Option<GenericLoopV0Facts>, Freeze> {
    let flat_body = flatten_scope_boxes(body);
    let strict = crate::config::env::joinir_dev::strict_enabled();

    let Some(loop_var) = extract_loop_var_for_subset(condition) else {
        return Ok(None);
    };

    let loop_increment = match extract_loop_increment_plan(&flat_body, &loop_var) {
        Ok(Some(inc)) => inc,
        _ => return Ok(None),
    };

    let step_placement = match classify_step_placement(
        &flat_body,
        &loop_var,
        &loop_increment,
        strict,
    )? {
        Some(placement) => placement,
        None => return Ok(None),
    };

    if matches!(step_placement, StepPlacement::InBody(idx)
        if !validate_in_body_step(&flat_body, idx, &loop_var, &loop_increment, strict)?)
    {
        return Ok(None);
    }

    if !body_is_generic_v0(&flat_body, &loop_var, &loop_increment) {
        return Ok(None);
    }

    Ok(Some(GenericLoopV0Facts {
        loop_var,
        condition: condition.clone(),
        loop_increment,
        body: flat_body,
    }))
}

fn extract_loop_var_for_subset(condition: &ASTNode) -> Option<String> {
    let ASTNode::BinaryOp {
        operator,
        left,
        right: _,
        ..
    } = condition
    else {
        return None;
    };

    match operator {
        BinaryOperator::Less
        | BinaryOperator::LessEqual
        | BinaryOperator::Greater
        | BinaryOperator::GreaterEqual
        | BinaryOperator::Equal
        | BinaryOperator::NotEqual => {}
        _ => return None,
    }

    let ASTNode::Variable { name, .. } = left.as_ref() else {
        return None;
    };
    Some(name.clone())
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum StepPlacement {
    Last,
    InBody(usize),
}

fn classify_step_placement(
    body: &[ASTNode],
    loop_var: &str,
    loop_increment: &ASTNode,
    strict: bool,
) -> Result<Option<StepPlacement>, Freeze> {
    let mut indices = Vec::new();
    for (idx, stmt) in body.iter().enumerate() {
        if matches_loop_increment(stmt, loop_var, loop_increment) {
            indices.push(idx);
        }
    }
    if indices.is_empty() {
        return Ok(None);
    }
    if indices.len() > 1 {
        return reject_or_none(
            strict,
            "generic loop v0.2: multiple step assignments in body",
        );
    }
    let idx = indices[0];
    if idx + 1 == body.len() {
        Ok(Some(StepPlacement::Last))
    } else {
        Ok(Some(StepPlacement::InBody(idx)))
    }
}

fn validate_in_body_step(
    body: &[ASTNode],
    step_index: usize,
    loop_var: &str,
    loop_increment: &ASTNode,
    strict: bool,
) -> Result<bool, Freeze> {
    if body_has_continue(body) {
        return reject_or_false(
            strict,
            "generic loop v0.2: in-body step + continue is not allowed",
        );
    }
    for stmt in body.iter().skip(step_index + 1) {
        if is_exit_if(stmt) || is_effect_if(stmt, loop_var, loop_increment) {
            return reject_or_false(
                strict,
                "generic loop v0.2: control flow after in-body step",
            );
        }
        if matches!(stmt, ASTNode::Break { .. } | ASTNode::Continue { .. } | ASTNode::Return { .. })
        {
            return reject_or_false(
                strict,
                "generic loop v0.2: exit after in-body step",
            );
        }
        if stmt_uses_loop_var(stmt, loop_var) {
            return reject_or_false(
                strict,
                "generic loop v0.2: loop var used after in-body step",
            );
        }
        if is_simple_assignment(stmt, loop_var)
            || is_local_init(stmt, loop_var)
            || is_effect_only_stmt(stmt)
        {
            continue;
        }
        return reject_or_false(
            strict,
            "generic loop v0.2: unsupported stmt after in-body step",
        );
    }
    Ok(true)
}

fn body_is_generic_v0(body: &[ASTNode], loop_var: &str, loop_increment: &ASTNode) -> bool {
    for stmt in body {
        if matches_loop_increment(stmt, loop_var, loop_increment) {
            continue;
        }
        if is_simple_assignment(stmt, loop_var) {
            continue;
        }
        if is_local_init(stmt, loop_var) {
            continue;
        }
        if is_exit_if(stmt) {
            continue;
        }
        if is_effect_if(stmt, loop_var, loop_increment) {
            continue;
        }
        if matches!(
            stmt,
            ASTNode::Break { .. }
                | ASTNode::Continue { .. }
                | ASTNode::Return { .. }
                | ASTNode::MethodCall { .. }
                | ASTNode::FunctionCall { .. }
        ) {
            continue;
        }
        return false;
    }
    true
}

fn matches_loop_increment(
    stmt: &ASTNode,
    loop_var: &str,
    loop_increment: &ASTNode,
) -> bool {
    let ASTNode::Assignment { target, value, .. } = stmt else {
        return false;
    };
    let ASTNode::Variable { name, .. } = target.as_ref() else {
        return false;
    };
    if name != loop_var {
        return false;
    }
    value.as_ref() == loop_increment
}

fn is_simple_assignment(stmt: &ASTNode, loop_var: &str) -> bool {
    let ASTNode::Assignment { target, value, .. } = stmt else {
        return false;
    };
    let ASTNode::Variable { name, .. } = target.as_ref() else {
        return false;
    };
    if name == loop_var {
        return false;
    }
    is_supported_value_expr(value)
}

fn is_local_init(stmt: &ASTNode, loop_var: &str) -> bool {
    let ASTNode::Local {
        variables,
        initial_values,
        ..
    } = stmt
    else {
        return false;
    };
    if variables.len() != initial_values.len() {
        return false;
    }
    for (name, init) in variables.iter().zip(initial_values.iter()) {
        if name == loop_var {
            return false;
        }
        let Some(init) = init.as_ref() else {
            return false;
        };
        if !is_supported_value_expr(init) {
            return false;
        }
    }
    true
}

fn is_exit_if(stmt: &ASTNode) -> bool {
    let ASTNode::If {
        condition,
        then_body,
        else_body,
        ..
    } = stmt
    else {
        return false;
    };
    if else_body.is_some() || then_body.len() != 1 {
        return false;
    }
    if !is_supported_bool_expr(condition) {
        return false;
    }
    matches!(
        then_body[0],
        ASTNode::Break { .. }
            | ASTNode::Continue { .. }
            | ASTNode::Return { .. }
    )
}

fn is_effect_if(stmt: &ASTNode, loop_var: &str, loop_increment: &ASTNode) -> bool {
    let ASTNode::If {
        condition,
        then_body,
        else_body,
        ..
    } = stmt
    else {
        return false;
    };
    if else_body.is_some() || then_body.is_empty() {
        return false;
    }
    if !is_supported_bool_expr(condition) {
        return false;
    }

    let last_is_continue = matches!(then_body.last(), Some(ASTNode::Continue { .. }));
    let mut saw_increment = false;

    for (idx, inner) in then_body.iter().enumerate() {
        let is_last = idx + 1 == then_body.len();
        if last_is_continue && is_last && matches!(inner, ASTNode::Continue { .. }) {
            continue;
        }
        if matches_loop_increment(inner, loop_var, loop_increment) {
            if !last_is_continue || idx + 2 != then_body.len() || saw_increment {
                return false;
            }
            saw_increment = true;
            continue;
        }
        if is_effect_only_stmt(inner) {
            continue;
        }
        return false;
    }

    true
}

fn is_supported_value_expr(ast: &ASTNode) -> bool {
    match ast {
        ASTNode::Variable { .. } => true,
        ASTNode::Literal { .. } => true,
        ASTNode::MethodCall { .. } => true,
        ASTNode::BinaryOp { operator, left: _, right: _, .. } => matches!(
            operator,
            BinaryOperator::Add
                | BinaryOperator::Subtract
                | BinaryOperator::Multiply
                | BinaryOperator::Divide
        ),
        _ => false,
    }
}

fn is_supported_bool_expr(ast: &ASTNode) -> bool {
    match ast {
        ASTNode::BinaryOp {
            operator,
            left,
            right,
            ..
        } => match operator {
            BinaryOperator::And | BinaryOperator::Or => {
                is_supported_bool_expr(left) && is_supported_bool_expr(right)
            }
            BinaryOperator::Less
            | BinaryOperator::LessEqual
            | BinaryOperator::Greater
            | BinaryOperator::GreaterEqual
            | BinaryOperator::Equal
            | BinaryOperator::NotEqual => {
                is_supported_value_expr(left) && is_supported_value_expr(right)
            }
            _ => false,
        },
        _ => false,
    }
}

fn body_has_continue(body: &[ASTNode]) -> bool {
    body.iter().any(stmt_has_continue)
}

fn stmt_has_continue(stmt: &ASTNode) -> bool {
    match stmt {
        ASTNode::Continue { .. } => true,
        ASTNode::If {
            then_body,
            else_body,
            ..
        } => {
            then_body.iter().any(stmt_has_continue)
                || else_body.as_ref().map_or(false, |body| {
                    body.iter().any(stmt_has_continue)
                })
        }
        ASTNode::ScopeBox { body, .. } => body.iter().any(stmt_has_continue),
        _ => false,
    }
}

fn stmt_uses_loop_var(stmt: &ASTNode, loop_var: &str) -> bool {
    match stmt {
        ASTNode::Variable { name, .. } => name == loop_var,
        ASTNode::Assignment { target, value, .. } => {
            stmt_uses_loop_var(target, loop_var) || stmt_uses_loop_var(value, loop_var)
        }
        ASTNode::BinaryOp { left, right, .. } => {
            stmt_uses_loop_var(left, loop_var) || stmt_uses_loop_var(right, loop_var)
        }
        ASTNode::UnaryOp { operand, .. } => stmt_uses_loop_var(operand, loop_var),
        ASTNode::MethodCall {
            object,
            arguments,
            ..
        } => {
            stmt_uses_loop_var(object, loop_var)
                || arguments.iter().any(|arg| stmt_uses_loop_var(arg, loop_var))
        }
        ASTNode::FunctionCall { arguments, .. } => {
            arguments
                .iter()
                .any(|arg| stmt_uses_loop_var(arg, loop_var))
        }
        ASTNode::If {
            condition,
            then_body,
            else_body,
            ..
        } => {
            stmt_uses_loop_var(condition, loop_var)
                || then_body.iter().any(|node| stmt_uses_loop_var(node, loop_var))
                || else_body.as_ref().map_or(false, |body| {
                    body.iter().any(|node| stmt_uses_loop_var(node, loop_var))
                })
        }
        ASTNode::Local {
            initial_values,
            ..
        } => initial_values.iter().any(|init| {
            init.as_ref()
                .map_or(false, |node| stmt_uses_loop_var(node, loop_var))
        }),
        ASTNode::Return { value, .. } => value
            .as_ref()
            .map_or(false, |node| stmt_uses_loop_var(node, loop_var)),
        ASTNode::ScopeBox { body, .. } => body.iter().any(|node| stmt_uses_loop_var(node, loop_var)),
        ASTNode::Break { .. }
        | ASTNode::Continue { .. }
        | ASTNode::Literal { .. } => false,
        _ => true,
    }
}

fn flatten_scope_boxes(body: &[ASTNode]) -> Vec<ASTNode> {
    let mut out = Vec::new();
    fn push_node(node: &ASTNode, out: &mut Vec<ASTNode>) {
        match node {
            ASTNode::ScopeBox { body, .. } => {
                for inner in body {
                    push_node(inner, out);
                }
            }
            _ => out.push(node.clone()),
        }
    }
    for stmt in body {
        push_node(stmt, &mut out);
    }
    out
}

fn reject_or_none<T>(strict: bool, message: &str) -> Result<Option<T>, Freeze> {
    if strict {
        Err(Freeze::ambiguous(message))
    } else {
        Ok(None)
    }
}

fn reject_or_false(strict: bool, message: &str) -> Result<bool, Freeze> {
    if strict {
        Err(Freeze::unsupported(message))
    } else {
        Ok(false)
    }
}

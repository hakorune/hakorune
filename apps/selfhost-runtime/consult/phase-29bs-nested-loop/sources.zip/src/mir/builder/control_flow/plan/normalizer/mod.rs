//! Phase 273 P1: PlanNormalizer - DomainPlan → CorePlan 変換 (SSOT)
//!
//! # Responsibilities
//!
//! - Convert DomainPlan to CorePlan (SSOT for pattern-specific knowledge)
//! - Generate ValueIds for CorePlan expressions
//! - Expand pattern-specific operations into generic CoreEffectPlan
//!
//! # Key Design Decision
//!
//! Normalizer is the ONLY place that knows pattern-specific semantics.
//! Lowerer processes CorePlan without any pattern knowledge.

pub(in crate::mir::builder) mod helpers;
mod pattern1_coreloop_builder;
mod pattern1_char_map;
mod pattern1_array_join;
mod pattern1_simple_while;
mod pattern2_break;
mod pattern3_if_phi;
mod pattern4_continue;
mod pattern5_infinite_early_exit;
mod pattern_is_integer;
mod pattern_starts_with;
mod pattern_int_to_str;
mod pattern_escape_map;
mod pattern_split_lines;
mod pattern_skip_ws;
mod pattern8_bool_predicate_scan;
mod pattern9_accum_const_loop;
mod pattern_scan_with_init;
mod pattern_split_scan;
mod skeleton_loop;
mod value_join_args;
mod common;
#[cfg(test)]
mod value_join_demo_if2;

use super::{
    CoreEffectPlan, CoreLoopPlan, CorePhiInfo, CorePlan, DomainPlan, Pattern1ArrayJoinPlan,
    Pattern1CharMapPlan, Pattern1SimpleWhilePlan, Pattern2BreakPlan, Pattern3IfPhiPlan,
    Pattern4ContinuePlan, Pattern5ExitKind, Pattern5InfiniteEarlyExitPlan,
    Pattern8BoolPredicateScanPlan, Pattern9AccumConstLoopPlan, ScanWithInitPlan, SplitScanPlan,
};
use crate::mir::builder::control_flow::joinir::patterns::router::LoopPatternContext;
use crate::mir::builder::MirBuilder;

pub(in crate::mir::builder) use pattern1_coreloop_builder::build_pattern1_coreloop;
pub(in crate::mir::builder) use pattern_is_integer::normalize_is_integer_minimal;
pub(in crate::mir::builder) use pattern_starts_with::normalize_starts_with_minimal;
pub(in crate::mir::builder) use pattern_int_to_str::normalize_int_to_str_minimal;
pub(in crate::mir::builder) use pattern_escape_map::normalize_escape_map_minimal;
pub(in crate::mir::builder) use pattern_split_lines::normalize_split_lines_minimal;
pub(in crate::mir::builder) use pattern_skip_ws::normalize_skip_ws_minimal;
pub(in crate::mir::builder) use super::generic_loop::normalizer::normalize_generic_loop_v0;

/// Phase 273 P1: PlanNormalizer - DomainPlan → CorePlan 変換 (SSOT)
pub(in crate::mir::builder) struct PlanNormalizer;

impl PlanNormalizer {
    /// Normalize DomainPlan to CorePlan
    ///
    /// This is the SSOT for pattern-specific knowledge expansion.
    /// All pattern semantics (scan, split, etc.) are expanded here.
    pub(in crate::mir::builder) fn normalize(
        builder: &mut MirBuilder,
        domain: DomainPlan,
        ctx: &LoopPatternContext,
    ) -> Result<CorePlan, String> {
        match domain {
            DomainPlan::ScanWithInit(parts) => Self::normalize_scan_with_init(builder, parts, ctx),
            DomainPlan::SplitScan(parts) => Self::normalize_split_scan(builder, parts, ctx),
            DomainPlan::Pattern4Continue(parts) => {
                Self::normalize_pattern4_continue(builder, parts, ctx)
            }
            DomainPlan::Pattern1SimpleWhile(parts) => {
                Self::normalize_pattern1_simple_while(builder, parts, ctx)
            }
            DomainPlan::Pattern1CharMap(parts) => {
                Self::normalize_pattern1_char_map(builder, parts, ctx)
            }
            DomainPlan::Pattern1ArrayJoin(parts) => {
                Self::normalize_pattern1_array_join(builder, parts, ctx)
            }
            DomainPlan::GenericLoopV0(parts) => {
                normalize_generic_loop_v0(builder, &parts, ctx)
            }
            DomainPlan::Pattern9AccumConstLoop(parts) => {
                Self::normalize_pattern9_accum_const_loop(builder, parts, ctx)
            }
            DomainPlan::Pattern8BoolPredicateScan(parts) => {
                Self::normalize_pattern8_bool_predicate_scan(builder, parts, ctx)
            }
            DomainPlan::Pattern3IfPhi(parts) => Self::normalize_pattern3_if_phi(builder, parts, ctx),
            DomainPlan::Pattern2Break(parts) => Self::normalize_pattern2_break(builder, parts, ctx),
            DomainPlan::Pattern5InfiniteEarlyExit(parts) => {
                Self::normalize_pattern5_infinite_early_exit(builder, parts, ctx)
            }
        }
    }
}

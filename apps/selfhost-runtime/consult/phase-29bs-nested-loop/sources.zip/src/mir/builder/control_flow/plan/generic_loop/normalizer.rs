//! Phase 29ca P1: Generic structured loop v0 normalizer (ExitIf + IfEffect, no carriers)

use crate::mir::builder::control_flow::plan::normalizer::helpers::create_phi_bindings;
use crate::mir::builder::control_flow::plan::normalizer::{build_pattern1_coreloop, PlanNormalizer};
use crate::ast::{ASTNode, BinaryOperator};
use crate::mir::builder::control_flow::joinir::patterns::router::LoopPatternContext;
use crate::mir::builder::control_flow::plan::coreloop_body_contract::is_effect_only_stmt;
use crate::mir::builder::control_flow::plan::{CoreEffectPlan, CoreExitPlan, CorePlan};
use crate::mir::builder::MirBuilder;
use crate::mir::{BinaryOp, ConstValue, MirType};
use super::facts::GenericLoopV0Facts;

pub(in crate::mir::builder) fn normalize_generic_loop_v0(
    builder: &mut MirBuilder,
    facts: &GenericLoopV0Facts,
    ctx: &LoopPatternContext,
) -> Result<CorePlan, String> {
    let mut loop_plan = build_pattern1_coreloop(
        builder,
        &facts.loop_var,
        &facts.condition,
        &facts.loop_increment,
        ctx,
    )?;

    let loop_var_current = loop_plan
        .final_values
        .iter()
        .find(|(name, _)| name == &facts.loop_var)
        .map(|(_, value)| *value)
        .ok_or_else(|| {
            format!(
                "[normalizer] loop var {} missing from final_values",
                facts.loop_var
            )
        })?;

    let phi_bindings = create_phi_bindings(&[(&facts.loop_var, loop_var_current)]);
    let mut effects = Vec::new();

    for stmt in &facts.body {
        if matches_loop_increment(stmt, &facts.loop_var, &facts.loop_increment) {
            continue;
        }

        match stmt {
            ASTNode::Assignment { target, value, .. } => {
                effects.extend(lower_assignment(
                    builder,
                    &phi_bindings,
                    target,
                    value,
                )?);
            }
            ASTNode::Local {
                variables,
                initial_values,
                ..
            } => {
                effects.extend(lower_local_init(
                    builder,
                    &phi_bindings,
                    variables,
                    initial_values,
                )?);
            }
            ASTNode::MethodCall { .. } => {
                effects.extend(lower_method_call_stmt(
                    builder,
                    &phi_bindings,
                    stmt,
                )?);
            }
            ASTNode::FunctionCall { .. } => {
                effects.extend(lower_function_call_stmt(
                    builder,
                    &phi_bindings,
                    stmt,
                )?);
            }
            ASTNode::If {
                condition,
                then_body,
                else_body,
                ..
            } => {
                if else_body.is_some() || then_body.is_empty() {
                    return Err("[normalizer] generic loop v0: unsupported if form".to_string());
                }
                let (cond_id, mut cond_effects) =
                    lower_bool_expr(builder, &phi_bindings, condition)?;
                effects.append(&mut cond_effects);

                if let Some(effect_stmts) = split_continue_then_body(
                    then_body,
                    &facts.loop_var,
                    &facts.loop_increment,
                ) {
                    let mut then_effects = Vec::new();
                    for stmt in effect_stmts {
                        then_effects.extend(lower_effect_only_stmt(
                            builder,
                            &phi_bindings,
                            stmt,
                        )?);
                    }
                    then_effects.push(CoreEffectPlan::ExitIf {
                        cond: cond_id,
                        exit: CoreExitPlan::Continue,
                    });
                    effects.push(CoreEffectPlan::IfEffect {
                        cond: cond_id,
                        then_effects,
                    });
                } else if then_body.len() == 1
                    && matches!(
                        then_body[0],
                        ASTNode::Break { .. }
                            | ASTNode::Continue { .. }
                            | ASTNode::Return { .. }
                    )
                {
                    let mut exit_effects = lower_exit_from_stmt(
                        builder,
                        &phi_bindings,
                        cond_id,
                        &then_body[0],
                    )?;
                    effects.append(&mut exit_effects);
                } else {
                    let mut then_effects = Vec::new();
                    for stmt in then_body {
                        then_effects.extend(lower_effect_only_stmt(
                            builder,
                            &phi_bindings,
                            stmt,
                        )?);
                    }
                    effects.push(CoreEffectPlan::IfEffect {
                        cond: cond_id,
                        then_effects,
                    });
                }
            }
            ASTNode::Break { .. }
            | ASTNode::Continue { .. }
            | ASTNode::Return { .. } => {
                let true_cond = builder.alloc_typed(MirType::Bool);
                effects.push(CoreEffectPlan::Const {
                    dst: true_cond,
                    value: ConstValue::Bool(true),
                });
                let mut exit_effects =
                    lower_exit_from_stmt(builder, &phi_bindings, true_cond, stmt)?;
                effects.append(&mut exit_effects);
            }
            _ => {
                return Err("[normalizer] generic loop v0: unsupported body stmt".to_string());
            }
        }
    }

    loop_plan.body = effects.into_iter().map(CorePlan::Effect).collect();
    Ok(CorePlan::Loop(loop_plan))
}

fn matches_loop_increment(
    stmt: &ASTNode,
    loop_var: &str,
    loop_increment: &ASTNode,
) -> bool {
    let ASTNode::Assignment { target, value, .. } = stmt else {
        return false;
    };
    let ASTNode::Variable { name, .. } = target.as_ref() else {
        return false;
    };
    if name != loop_var {
        return false;
    }
    value.as_ref() == loop_increment
}

fn split_continue_then_body<'a>(
    then_body: &'a [ASTNode],
    loop_var: &str,
    loop_increment: &ASTNode,
) -> Option<Vec<&'a ASTNode>> {
    if then_body.is_empty() {
        return None;
    }
    if !matches!(then_body.last(), Some(ASTNode::Continue { .. })) {
        return None;
    }
    if then_body.len() == 1 {
        return None;
    }

    let mut effects = Vec::new();
    let mut saw_increment = false;
    for (idx, stmt) in then_body.iter().enumerate() {
        let is_last = idx + 1 == then_body.len();
        if is_last {
            return Some(effects);
        }
        if matches_loop_increment(stmt, loop_var, loop_increment) {
            if idx + 2 != then_body.len() || saw_increment {
                return None;
            }
            saw_increment = true;
            continue;
        }
        if is_effect_only_stmt(stmt) {
            effects.push(stmt);
            continue;
        }
        return None;
    }
    None
}

fn lower_assignment(
    builder: &mut MirBuilder,
    phi_bindings: &std::collections::BTreeMap<String, crate::mir::ValueId>,
    target: &ASTNode,
    value: &ASTNode,
) -> Result<Vec<CoreEffectPlan>, String> {
    let ASTNode::Variable { name, .. } = target else {
        return Err("[normalizer] generic loop v0: non-variable assignment".to_string());
    };
    let (value_id, effects) = PlanNormalizer::lower_value_ast(value, builder, phi_bindings)?;
    builder
        .variable_ctx
        .variable_map
        .insert(name.to_string(), value_id);
    Ok(effects)
}

fn lower_local_init(
    builder: &mut MirBuilder,
    phi_bindings: &std::collections::BTreeMap<String, crate::mir::ValueId>,
    variables: &[String],
    initial_values: &[Option<Box<ASTNode>>],
) -> Result<Vec<CoreEffectPlan>, String> {
    if variables.len() != initial_values.len() {
        return Err("[normalizer] generic loop v0: local init arity mismatch".to_string());
    }
    let mut effects = Vec::new();
    for (name, init) in variables.iter().zip(initial_values.iter()) {
        let Some(init) = init.as_ref() else {
            return Err("[normalizer] generic loop v0: local init missing value".to_string());
        };
        let (value_id, mut init_effects) =
            PlanNormalizer::lower_value_ast(init, builder, phi_bindings)?;
        effects.append(&mut init_effects);
        builder
            .variable_ctx
            .variable_map
            .insert(name.to_string(), value_id);
    }
    Ok(effects)
}

fn lower_method_call_stmt(
    builder: &mut MirBuilder,
    phi_bindings: &std::collections::BTreeMap<String, crate::mir::ValueId>,
    stmt: &ASTNode,
) -> Result<Vec<CoreEffectPlan>, String> {
    let ASTNode::MethodCall {
        object,
        method,
        arguments,
        ..
    } = stmt
    else {
        return Err("[normalizer] generic loop v0: expected method call".to_string());
    };

    let mut arg_ids = Vec::new();
    let mut effects = Vec::new();
    for arg in arguments {
        let (arg_id, mut arg_effects) =
            PlanNormalizer::lower_value_ast(arg, builder, phi_bindings)?;
        arg_ids.push(arg_id);
        effects.append(&mut arg_effects);
    }

    match object.as_ref() {
        ASTNode::Variable { name, .. } => {
            let object_id = if let Some(&phi_dst) = phi_bindings.get(name) {
                phi_dst
            } else if let Some(&value_id) = builder.variable_ctx.variable_map.get(name) {
                value_id
            } else {
                return Err(format!(
                    "[normalizer] generic loop v0: method call object {} not found",
                    name
                ));
            };
            effects.push(CoreEffectPlan::MethodCall {
                dst: None,
                object: object_id,
                method: method.clone(),
                args: arg_ids,
                effects: crate::mir::EffectMask::PURE.add(crate::mir::Effect::Io),
            });
        }
        ASTNode::This { .. } | ASTNode::Me { .. } => {
            let Some(box_name) = builder.comp_ctx.current_static_box.clone() else {
                return Err(
                    "[normalizer] generic loop v0: this.method without static box".to_string()
                );
            };
            let func = format!("{}.{}/{}", box_name, method, arguments.len());
            effects.push(CoreEffectPlan::GlobalCall {
                dst: None,
                func,
                args: arg_ids,
            });
        }
        _ => {
            let (object_id, mut obj_effects) =
                PlanNormalizer::lower_value_ast(object, builder, phi_bindings)?;
            effects.append(&mut obj_effects);
            effects.push(CoreEffectPlan::MethodCall {
                dst: None,
                object: object_id,
                method: method.clone(),
                args: arg_ids,
                effects: crate::mir::EffectMask::PURE.add(crate::mir::Effect::Io),
            });
        }
    }

    Ok(effects)
}

fn lower_function_call_stmt(
    builder: &mut MirBuilder,
    phi_bindings: &std::collections::BTreeMap<String, crate::mir::ValueId>,
    stmt: &ASTNode,
) -> Result<Vec<CoreEffectPlan>, String> {
    let ASTNode::FunctionCall {
        name,
        arguments,
        ..
    } = stmt
    else {
        return Err("[normalizer] generic loop v0: expected function call".to_string());
    };

    let mut arg_ids = Vec::new();
    let mut effects = Vec::new();
    for arg in arguments {
        let (arg_id, mut arg_effects) =
            PlanNormalizer::lower_value_ast(arg, builder, phi_bindings)?;
        arg_ids.push(arg_id);
        effects.append(&mut arg_effects);
    }
    effects.push(CoreEffectPlan::GlobalCall {
        dst: None,
        func: name.clone(),
        args: arg_ids,
    });
    Ok(effects)
}

fn lower_effect_only_stmt(
    builder: &mut MirBuilder,
    phi_bindings: &std::collections::BTreeMap<String, crate::mir::ValueId>,
    stmt: &ASTNode,
) -> Result<Vec<CoreEffectPlan>, String> {
    match stmt {
        ASTNode::MethodCall { .. } => lower_method_call_stmt(builder, phi_bindings, stmt),
        ASTNode::FunctionCall { .. } => lower_function_call_stmt(builder, phi_bindings, stmt),
        _ => Err("[normalizer] generic loop v0: unsupported if-effect stmt".to_string()),
    }
}

fn lower_exit_from_stmt(
    builder: &mut MirBuilder,
    phi_bindings: &std::collections::BTreeMap<String, crate::mir::ValueId>,
    cond: crate::mir::ValueId,
    stmt: &ASTNode,
) -> Result<Vec<CoreEffectPlan>, String> {
    let mut effects = Vec::new();
    let exit = match stmt {
        ASTNode::Break { .. } => CoreExitPlan::Break,
        ASTNode::Continue { .. } => CoreExitPlan::Continue,
        ASTNode::Return { value, .. } => {
            let Some(value) = value.as_ref() else {
                return Err("[normalizer] generic loop v0: return without value".to_string());
            };
            let (value_id, mut return_effects) =
                PlanNormalizer::lower_value_ast(value, builder, phi_bindings)?;
            effects.append(&mut return_effects);
            CoreExitPlan::Return(Some(value_id))
        }
        _ => {
            return Err("[normalizer] generic loop v0: unsupported exit".to_string());
        }
    };

    effects.push(CoreEffectPlan::ExitIf { cond, exit });
    Ok(effects)
}

fn lower_bool_expr(
    builder: &mut MirBuilder,
    phi_bindings: &std::collections::BTreeMap<String, crate::mir::ValueId>,
    ast: &ASTNode,
) -> Result<(crate::mir::ValueId, Vec<CoreEffectPlan>), String> {
    match ast {
        ASTNode::BinaryOp {
            operator,
            left,
            right,
            ..
        } => match operator {
            BinaryOperator::And | BinaryOperator::Or => {
                let (lhs, mut lhs_effects) = lower_bool_expr(builder, phi_bindings, left)?;
                let (rhs, mut rhs_effects) = lower_bool_expr(builder, phi_bindings, right)?;
                let dst = builder.alloc_typed(MirType::Bool);
                lhs_effects.append(&mut rhs_effects);
                lhs_effects.push(CoreEffectPlan::BinOp {
                    dst,
                    lhs,
                    op: match operator {
                        BinaryOperator::And => BinaryOp::And,
                        BinaryOperator::Or => BinaryOp::Or,
                        _ => unreachable!(),
                    },
                    rhs,
                });
                Ok((dst, lhs_effects))
            }
            BinaryOperator::Less
            | BinaryOperator::LessEqual
            | BinaryOperator::Greater
            | BinaryOperator::GreaterEqual
            | BinaryOperator::Equal
            | BinaryOperator::NotEqual => {
                let (lhs, op, rhs, mut consts) =
                    PlanNormalizer::lower_compare_ast(ast, builder, phi_bindings)?;
                let dst = builder.alloc_typed(MirType::Bool);
                consts.push(CoreEffectPlan::Compare { dst, lhs, op, rhs });
                Ok((dst, consts))
            }
            _ => Err("[normalizer] generic loop v0: unsupported bool op".to_string()),
        },
        _ => Err("[normalizer] generic loop v0: unsupported bool expr".to_string()),
    }
}

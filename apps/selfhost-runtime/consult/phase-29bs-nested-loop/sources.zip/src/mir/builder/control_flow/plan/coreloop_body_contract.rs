//! Core loop body effect contract (SSOT)
//!
//! - Leaf effects: simple, side-effecting instructions
//! - Control-flow effects: ExitIf / IfEffect (loop-only)
//! - AST helpers for generic loop normalization

use crate::ast::ASTNode;

use super::{CoreEffectPlan, CoreExitPlan};

pub(in crate::mir::builder) fn is_leaf_effect_plan(effect: &CoreEffectPlan) -> bool {
    matches!(
        effect,
        CoreEffectPlan::MethodCall { .. }
            | CoreEffectPlan::GlobalCall { .. }
            | CoreEffectPlan::BinOp { .. }
            | CoreEffectPlan::Compare { .. }
            | CoreEffectPlan::Const { .. }
    )
}

pub(in crate::mir::builder) fn has_control_flow_effect(effects: &[CoreEffectPlan]) -> bool {
    effects.iter().any(|effect| {
        matches!(
            effect,
            CoreEffectPlan::ExitIf { .. } | CoreEffectPlan::IfEffect { .. }
        )
    })
}

pub(in crate::mir::builder) fn if_effect_tail_continue(
    effects: &[CoreEffectPlan],
) -> Option<&CoreEffectPlan> {
    match effects.split_last() {
        Some((CoreEffectPlan::ExitIf { exit: CoreExitPlan::Continue, .. }, _)) => {
            effects.last()
        }
        _ => None,
    }
}

pub(in crate::mir::builder) fn is_effect_only_stmt(stmt: &ASTNode) -> bool {
    matches!(stmt, ASTNode::MethodCall { .. } | ASTNode::FunctionCall { .. })
}
